//
//  ViewController.m
//  zad2PS6
//
//  Created by student on 11/10/2021.
//  Copyright © 2021 pb. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
-(IBAction)enter{
    NSString *yourName = self.InputField.text;
    NSString *myName = @"Marcin";
    NSString *message;
    
        if([yourName length] == 0)
        {
            yourName = @"World";
        }
        if([yourName isEqualToString:myName])
        {
            message = [NSString stringWithFormat:@"Hello %@, we have the same name", yourName];
        }
        else
        {
            message = [NSString stringWithFormat:@"Hello %@", yourName];
        }
    
        self.messageLabel.text = message;
    
     }
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    
  if([segue.identifier isEqualToString:@"sendsurenamesegue"])
  {
      SecondViewController *controller= (SecondViewController *)segue.destinationViewController;
      controller.surename = self.SurenameField.text;
      controller.delegate=self;
  }

};

-(void)additemviewcontroller:(SecondViewController *)controller didFinishEnteringItem:(NSString *)item
{
   NSLog (@"This was returned from secondviewcontroller %@", item);
    self.SurenameField.text = item;
}
@end
