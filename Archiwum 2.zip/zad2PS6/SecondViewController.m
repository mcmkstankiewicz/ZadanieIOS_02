//
//  SecondViewController.m
//  zad2PS6
//
//  Created by student on 11/10/2021.
//  Copyright © 2021 pb. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.modifiedsurenametextfield.text = self.surename;
    // Do any additional setup after loading the view.
}

-(IBAction)return
{
    NSString *itemtopassback = self.modifiedsurenametextfield.text;
    [self.delegate additemviewcontroller:self didFinishEnteringItem:itemtopassback];
    [self dismissViewControllerAnimated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
